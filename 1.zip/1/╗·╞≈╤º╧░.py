
# -*- coding:utf-8 -*-
import numpy as np
import pandas as pd
import os
import joblib
import json
import csv

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, f1_score, precision_score, recall_score, precision_recall_curve, auc

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
import xgboost as xgb
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.neural_network import MLPClassifier

initial_data = [["正样本数量", "样本总数量", "acc", "精准率", "召回率", "f1", "roc_auc", "pr_auc"]]

model_names = ['RF', 'XGB', 'NB', 'GBDT', 'KNN', 'LinearSVM', 'LR', 'MLP']
for model_name in model_names:
    with open(f'{model_name}_fengdu.csv', mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(initial_data)

gut_data = pd.read_csv(r'E:/桌面/20240925_Chunming/yuce/3. gut_predict_simple/dis_data/merge_dis_data.csv')

label_dict = {'0': '健康', '1': '代谢/内分泌', '2': '消化道', '4': '精神/神经', '5': '免疫/呼吸/皮肤', '53': 'A',
              '54': 'C', '55': 'E', '56': 'F'}

dis_map = json.load(open(r'E:/桌面/20240925_Chunming/yuce/3. gut_predict_simple/dis_map.json', 'r'))
for pcls in dis_map:
    if int(pcls) < 6:
        continue
    for pdis in dis_map[pcls]:
        label_dict[pcls] = pdis

m = sum(['_label' in col for col in gut_data.columns])

for plabel in sorted(label_dict.keys()):
    if int(plabel) > 52:
        print(label_dict[plabel])
        py = gut_data.loc[:, plabel + '_label'].to_numpy()
        px = gut_data.iloc[:, :-m]

        psdir = './丰度/{}_model/'.format(plabel)
        if not os.path.exists(psdir):
            os.makedirs(psdir)

        skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
        for i, (train_i, test_i) in enumerate(skf.split(px, py)):
            sub_x0 = px.iloc[train_i, :]
            sub_y0 = py[train_i]
            sub_x1 = px.iloc[test_i, :]
            sub_y1 = py[test_i]

            # ================== RF 模型 ==================
            clf = RandomForestClassifier()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"RF: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('RF_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_rf_丰度.joblib'.format(i))

            # ================== XGB 模型 ==================
            clf = xgb.XGBClassifier()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"XGB: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('XGB_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_xgb_丰度.joblib'.format(i))

            # ================== NB 模型 ==================
            clf = GaussianNB()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"NB: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('NB_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_nb_丰度.joblib'.format(i))

            # ================== GBDT 模型 ==================
            clf = GradientBoostingClassifier()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"GBDT: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('GBDT_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_gbdt_丰度.joblib'.format(i))

            # ================== KNN 模型 ==================
            clf = KNeighborsClassifier()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"KNN: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('KNN_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_knn_丰度.joblib'.format(i))

            # ================== LinearSVM 模型 ==================
            clf = LinearSVC()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.decision_function(sub_x1)
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"LinearSVM: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('LinearSVM_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_linearsvm_丰度.joblib'.format(i))

            # ================== LR 模型 ==================
            clf = LogisticRegression()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"LR: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('LR_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_lr_丰度.joblib'.format(i))

            # ================== MLP 模型 ==================
            clf = MLPClassifier()
            clf.fit(sub_x0, sub_y0)
            test_pred = clf.predict(sub_x1)
            test_proba = clf.predict_proba(sub_x1)[:, 1]
            acc = clf.score(sub_x1, sub_y1)
            precision = precision_score(sub_y1, test_pred)
            recall = recall_score(sub_y1, test_pred)
            f1 = f1_score(sub_y1, test_pred)
            auc_score = roc_auc_score(sub_y1, test_proba)
            precision_vals, recall_vals, _ = precision_recall_curve(sub_y1, test_proba)
            pr_auc = auc(recall_vals, precision_vals)

            print(f"MLP: " + ",".join([
                str(int(np.sum(py))),
                str(len(py)),
                f"{acc:.3f}",
                f"{precision:.3f}",
                f"{recall:.3f}",
                f"{f1:.3f}",
                f"{auc_score:.3f}",
                f"{pr_auc:.3f}"
            ]))

            with open('MLP_fengdu.csv', mode='a', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow([
                    f"{int(np.sum(py))}",
                    f"{len(py)}",
                    f"{acc:.3f}",
                    f"{precision:.3f}",
                    f"{recall:.3f}",
                    f"{f1:.3f}",
                    f"{auc_score:.3f}",
                    f"{pr_auc:.3f}"
                ])

            joblib.dump(clf, psdir + '/{}_mlp_丰度.joblib'.format(i))
