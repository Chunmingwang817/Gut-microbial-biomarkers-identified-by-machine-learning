# ========= 后端需在 pyplot 之前设置 =========
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import os
import sys
import itertools
import numpy as np
import pandas as pd
import seaborn as sns

from skbio.diversity.alpha import shannon, chao1, simpson
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.multitest import multipletests
import sys
sys.stdout.reconfigure(encoding='utf-8')
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass


# ==========================
otu_path = r"E:\桌面\otu_table.csv"
meta_path = r"E:\桌面\metadata.csv"
out_dir  = r"E:\桌面\多样性分析\含显著性标注"
os.makedirs(out_dir, exist_ok=True)

# ==========================
# 工具函数
# ==========================
def p_to_star(p):
    if p is None or (isinstance(p, float) and np.isnan(p)): return 'ns'
    if p < 0.001: return '***'
    elif p < 0.01: return '**'
    elif p < 0.05: return '*'
    else: return 'ns'

def draw_sig_bar(ax, x1, x2, y, text, y_step, lw=1.0):
    ax.plot([x1, x1, x2, x2], [y, y + y_step*0.25, y + y_step*0.25, y], lw=lw, c='k')
    ax.text((x1 + x2)/2, y + y_step*0.3, text, ha='center', va='bottom', fontsize=9)

def safe_name(s: str) -> str:
    return str(s).replace(' ', '_').replace('/', '_')

# ==========================
# 数据读取与预处理
# ==========================
otu = pd.read_csv(otu_path, index_col=0)
meta = pd.read_csv(meta_path)
meta.columns = meta.columns.str.strip().str.lower()

assert 'sampleid' in meta.columns and 'group' in meta.columns, \
    "metadata.csv 必须包含 sampleid 和 group 列"

meta = meta.set_index('sampleid')
otu = otu.apply(pd.to_numeric, errors='coerce').fillna(0)

# 判断样本方向
if set(meta.index).issubset(otu.columns):
    otu_samp = otu.T
elif set(meta.index).issubset(otu.index):
    otu_samp = otu
else:
    raise ValueError("无法匹配 sampleid，请检查 metadata 与 OTU 表是否方向一致。")

common = sorted(set(otu_samp.index) & set(meta.index))
if len(common) < 3:
    raise ValueError("公共样本太少，无法进行分析。")

otu_samp = otu_samp.loc[common]
meta = meta.loc[common]

# ==========================
# 计算 alpha 多样性指标
# ==========================
alpha_df = pd.DataFrame(index=otu_samp.index)
alpha_df['Shannon'] = otu_samp.apply(lambda x: shannon(x.values) if x.sum() > 0 else np.nan, axis=1)
alpha_df['Chao1']   = otu_samp.apply(lambda x: chao1(x.values)   if x.sum() > 0 else np.nan, axis=1)
alpha_df['Simpson'] = otu_samp.apply(lambda x: simpson(x.values) if x.sum() > 0 else np.nan, axis=1)
alpha_df['Observed_OTUs'] = (otu_samp > 0).sum(axis=1).astype(int)
S = alpha_df['Observed_OTUs'].astype(float)
alpha_df['Pielou_evenness'] = np.where(S > 1, alpha_df['Shannon'] / np.log(S), np.nan)
alpha_df['Group'] = meta['group'].astype(str)

# ==========================
# 正态性检验（按 metric × group）
# ==========================
metrics_all = ['Shannon', 'Chao1', 'Simpson', 'Observed_OTUs', 'Pielou_evenness']
groups_all = list(dict.fromkeys(meta['group']))

normality_rows = []
for m in metrics_all:
    df_m = alpha_df[['Group', m]].copy()
    for g in groups_all:
        vals = df_m.loc[df_m['Group'] == g, m].dropna()
        n = len(vals)
        if n >= 3:
            W, p = stats.shapiro(vals)
            normality_rows.append({'metric': m, 'group': g, 'n': int(n), 'shapiro_W': float(W), 'shapiro_p': float(p)})
        else:
            normality_rows.append({'metric': m, 'group': g, 'n': int(n), 'shapiro_W': np.nan, 'shapiro_p': np.nan})

normality_df = pd.DataFrame(normality_rows)
normality_df.to_csv(os.path.join(out_dir, "alpha_normality_by_group.csv"),
                    index=False, encoding='utf-8-sig')
print("[OK] 输出正态性检验结果")

# ==========================
# 绘图 + 显著性标注
# ==========================
metrics_plot = ['Shannon', 'Simpson', 'Pielou_evenness']

for m in metrics_plot:
    df_m = alpha_df[['Group', m]].dropna()
    groups_m = [g for g in groups_all if g in df_m['Group'].unique()]
    if len(groups_m) < 2:
        print(f"[警告] 指标 {m} 组数不足，跳过绘图。")
        continue

    # 判断正态性 + 方差齐性
    group_data = [df_m.loc[df_m['Group']==g, m] for g in groups_m]
    group_normal_p = []
    for g in groups_m:
        vals = df_m.loc[df_m['Group']==g, m]
        if len(vals) >= 3:
            _, p_norm = stats.shapiro(vals)
            group_normal_p.append(float(p_norm))
        else:
            group_normal_p.append(0.0)
    all_normal = all(p > 0.05 for p in group_normal_p)

    if all_normal:
        _, levene_p = stats.levene(*group_data)
    else:
        levene_p = np.nan

    # 统计检验
    if all_normal and (np.isnan(levene_p) or levene_p > 0.05):
        test_used = "ANOVA"
        stat, p_val = stats.f_oneway(*group_data)
        tuk = pairwise_tukeyhsd(endog=df_m[m], groups=df_m['Group'], alpha=0.05)
        tuk_df = pd.DataFrame(tuk._results_table.data[1:], columns=tuk._results_table.data[0])
        tuk_df.columns = ['group1','group2','meandiff','p_adj','lower','upper','reject']
        sig_pairs = [(r.group1, r.group2, r.p_adj) for r in tuk_df.itertuples()]
    else:
        test_used = "Kruskal-Wallis"
        stat, p_val = stats.kruskal(*group_data)
        pairs = list(itertools.combinations(groups_m, 2))
        rows, p_raw = [], []
        for g1, g2 in pairs:
            v1, v2 = df_m.loc[df_m['Group']==g1, m], df_m.loc[df_m['Group']==g2, m]
            if len(v1) > 0 and len(v2) > 0:
                _, p = stats.mannwhitneyu(v1, v2, alternative='two-sided')
                p_raw.append(p)
                rows.append((g1, g2))
        p_adj = multipletests(p_raw, method='holm')[1] if len(p_raw)>0 else []
        sig_pairs = [(g1, g2, p) for (g1, g2), p in zip(rows, p_adj)]

    # 绘制箱线图 + 显著性标注
    plt.figure(figsize=(8,5))
    ax = sns.boxplot(data=df_m, x='Group', y=m, order=groups_m, palette='Set2')
    ax.set_xlabel("Group"); ax.set_ylabel(m)
    ax.set_title(f"{m} ({test_used} p={p_val:.3e})")
    xticks = {g:i for i,g in enumerate(groups_m)}

    y_min, y_max = df_m[m].min(), df_m[m].max()
    y_step = (y_max - y_min) * 0.08 if y_max>y_min else 0.2
    current_y = y_max + y_step

    for g1, g2, p in sorted(sig_pairs, key=lambda r:(abs(xticks[r[0]]-xticks[r[1]]), r[2])):
        if g1 in xticks and g2 in xticks:
            label = f"{p_to_star(p)} (p={p:.3g})"
            draw_sig_bar(ax, xticks[g1], xticks[g2], current_y, label, y_step)
            current_y += y_step

    plt.tight_layout()
    fname_box = os.path.join(out_dir, f"{safe_name(m)}_boxplot_sig.png")
    plt.savefig(fname_box, dpi=300)
    plt.close()
    print(f"[OK] {m} 箱线图保存：{fname_box}")

    # 绘制均值 ± SEM 条形图
    stat_tbl = df_m.groupby('Group')[m].agg(['mean','std','count']).reindex(groups_m)
    stat_tbl['sem'] = stat_tbl['std'] / np.sqrt(stat_tbl['count'].clip(lower=1))
    x = np.arange(len(groups_m))
    plt.figure(figsize=(8,5))
    plt.bar(x, stat_tbl['mean'], yerr=stat_tbl['sem'], capsize=4, color=sns.color_palette('Set2', n_colors=len(groups_m)))
    plt.xticks(x, groups_m)
    plt.ylabel(m); plt.xlabel("Group")
    plt.title(f"{m} — Mean ± SEM")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"{safe_name(m)}_bar_sem.png"), dpi=300)
    plt.close()

print("\n[完成] 已输出正态性检验与带显著性标注的图表。")
