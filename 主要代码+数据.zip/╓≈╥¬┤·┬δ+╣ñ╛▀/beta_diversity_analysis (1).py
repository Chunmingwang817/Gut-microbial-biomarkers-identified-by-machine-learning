# ============================================
# Beta Diversity Analysis (Bray–Curtis + PCoA + PERMANOVA)
# ============================================

import matplotlib
matplotlib.use('TkAgg')

# ====== 设置全局字体为 Arial ======
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Arial'
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from skbio.diversity import beta_diversity
from skbio.stats.ordination import pcoa
from skbio.stats.distance import permanova

# =============== 数据读取 =================
otu = pd.read_csv(r"E:\桌面\otu_table.csv", index_col=0)
meta = pd.read_csv(r"E:\桌面\metadata.csv")

# 标准化元数据列名
meta.columns = meta.columns.str.strip().str.lower()
meta = meta.set_index('sampleid')
print(" Step 1: 文件读取完成")

# =============== 修复索引 =================
# 保证 OTU 表与元数据样本数一致
otu.index = [f"A{i+1}" for i in range(len(otu))]
meta.index = otu.index
print(" Step 2: 样本索引已统一")

# =============== 数据清洗 =================
otu_clean = otu.apply(pd.to_numeric, errors='coerce').fillna(0)
print(" Step 3: OTU 表已数值化并填充缺失值")

# =============== 计算 Bray–Curtis 距离矩阵 =================
bc_dm = beta_diversity("braycurtis", otu_clean.values, otu_clean.index)
print(" Step 4: Bray–Curtis 距离矩阵已生成")

# =============== PCoA 分析 =================
pcoa_results = pcoa(bc_dm)
pcoa_df = pcoa_results.samples.copy()
pcoa_df['Group'] = meta['group'].astype(str)
print(" Step 5: PCoA 分析完成")

# =============== PERMANOVA 检验 =================
result = permanova(distance_matrix=bc_dm, grouping=meta['group'], permutations=999)
print("Step 6: PERMANOVA 检验完成")

# ---------- 自定义：高区分度四色 & 不同点形 ----------
okabe_ito_4 = ['#0072B2', '#D55E00', '#009E73', '#CC79A7']  # 蓝/橙/绿/洋红（色盲友好）
unique_groups = sorted(pcoa_df['Group'].unique())
# 颜色映射（超过4组则循环使用）
palette_map = {g: okabe_ito_4[i % len(okabe_ito_4)] for i, g in enumerate(unique_groups)}
# 形状映射（同理循环）
marker_list = ['o', 's', '^', 'D']
markers_map = {g: marker_list[i % len(marker_list)] for i, g in enumerate(unique_groups)}

# =============== 绘制 PCoA 散点图 =================
plt.figure(figsize=(10, 6))
sns.scatterplot(
    data=pcoa_df,
    x='PC1', y='PC2',
    hue='Group',
    style='Group',                    # 按组设定不同形状
    markers=markers_map,              # 明确的形状映射
    palette=palette_map,              # 高区分度四色
    s=10,                             # 点更小
    alpha=0.9,                        # 轻微透明，缓解重叠
    edgecolor='none'                  # 去掉黑色边线，视觉更清爽
)

# 使用 .iloc[] 访问比例，避免 FutureWarning
pc1_var = pcoa_results.proportion_explained.iloc[0] * 100
pc2_var = pcoa_results.proportion_explained.iloc[1] * 100

plt.title(f"Beta Diversity (Bray–Curtis) - PCoA\nPERMANOVA p={result['p-value']:.4f}", fontsize=18)
plt.xlabel(f"PC1 ({pc1_var:.2f}% explained variance)", fontsize=16)
plt.ylabel(f"PC2 ({pc2_var:.2f}% explained variance)", fontsize=16)
plt.legend(title='Group', loc='best', frameon=True)
plt.tight_layout()

# =============== 保存与显示 =================
output_fig = r"E:\桌面\机器学习结果\beta_diversity_pcoa.png"
output_csv = r"E:\桌面\机器学习结果\pcoa_coordinates.csv"

plt.savefig(output_fig, dpi=300)
plt.show()

# 保存 PCoA 坐标
pcoa_df.to_csv(output_csv, index=True, encoding='utf-8-sig')

print("Step 7: 图像与坐标文件已保存")
print("分析完成！结果如下：\n")
print(result)
